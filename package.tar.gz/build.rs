fn main() -> Result<(), Box<dyn std::error::Error>> {
    // 身份认证相关
    tonic_build::configure()
        .build_server(false)
        .build_client(true)
        .out_dir("src/pb")
        .compile(&["./src/bilibili/metadata/device/device.proto"], &["./src"])?;
    tonic_build::configure()
        .build_server(false)
        .build_client(true)
        .out_dir("src/pb")
        .compile(&["./src/bilibili/metadata/fawkes/fawkes.proto"], &["./src"])?;
    tonic_build::configure()
        .build_server(false)
        .build_client(true)
        .out_dir("src/pb")
        .compile(&["./src/bilibili/metadata/locale/locale.proto"], &["./src"])?;
    tonic_build::configure()
        .build_server(false)
        .build_client(true)
        .out_dir("src/pb")
        .compile(&["./src/bilibili/metadata/network/network.proto"], &["./src"])?;
    tonic_build::configure()
        .build_server(false)
        .build_client(true)
        .out_dir("src/pb")
        .compile(&["./src/bilibili/metadata/parabox/pararbox.proto"], &["./src"])?;
    tonic_build::configure()
        .build_server(false)
        .build_client(true)
        .out_dir("src/pb")
        .compile(&["./src/bilibili/metadata/restriction/restriction.proto"], &["./src"])?;
    tonic_build::configure()
        .build_server(false) // 是否编译生成用于服务端的代码
        .build_client(true) // 是否编译生成用于客户端的代码
        .out_dir("src/pb") // 输出的路径，此处指定为项目根目录下的protos目录
        // 指定要编译的proto文件路径列表，第二个参数是提供protobuf的扩展路径，
        // 因为protobuf官方提供了一些扩展功能，自己也可能会写一些扩展功能，
        // 如存在，则指定扩展文件路径，如果没有，则指定为proto文件所在目录即可
        .compile(&["./src/bilibili/metadata/metadata.proto"], &["./src"])?;
    // 实际功能实现
    tonic_build::configure()
        .build_server(false)
        .build_client(true)
        .out_dir("src/pb")
        .compile(&["./src/bilibili/pagination/pagination.proto"], &["./src"])?;
    tonic_build::configure()
        .build_server(false)
        .build_client(true)
        .out_dir("src/pb")
        .compile(
            &["./src/bilibili/app/archive/middleware/v1/preload.proto"],
            &["./src"],
        )?;
    tonic_build::configure()
        .build_server(false)
        .build_client(true)
        .out_dir("src/pb")
        .compile(
            &["./src/bilibili/pgc/gateway/player/v2/playurl.proto"],
            &["./src"],
        )?;
    tonic_build::configure()
        .build_server(false)
        .build_client(true)
        .out_dir("src/pb")
        // 涉及import其他proto, 注意此处extern_path, 类比即可
        .extern_path(
            ".bilibili.app.archive.middleware.v1",
            "crate::pb::bilibili_app_archive_middleware_v1",
        )
        .extern_path(".bilibili.pagination", "crate::pb::bilibili_pagination")
        .compile(
            &["./src/bilibili/polymer/app/search/v1/search.proto"],
            &["./src"],
        )?;
    Ok(())
}
